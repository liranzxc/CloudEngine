http://3.9.115.114:3000/swagger/

if you want to start the src code do:
1) npm install
2) npm run build
3) npm start


Liran Nachman - 311342836
Eden Dupont - 204808596
Aaron Reuven - 204880082